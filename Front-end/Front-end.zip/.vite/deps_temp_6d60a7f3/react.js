import {
  require_react
} from "./chunk-4SFRHSJ3.js";
import "./chunk-EQCVQC35.js";
export default require_react();
//# sourceMappingURL=react.js.map
